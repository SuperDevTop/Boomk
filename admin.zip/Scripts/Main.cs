using System.Collections;
using System.Collections.Generic;
using System.IO;
using System;
using UnityEngine;
using UnityEngine.UI;
using UnityEditor;
using SFB;

public class Main : MonoBehaviour
{
    public GameObject loadMenu;
    public GameObject settingsMenu;
    public GameObject alert;
    public GameObject mainGUI;
    public InputField createInput;
    public InputField browseInput;
    public InputField chooseInput;
    public InputField nickNameInput;
    public Dropdown createDropL;
    public Button loadBtn;
    public Button addBtn;
    public Button saveBtn;

    //Modify here
    public GameObject interrupt;
    public GameObject sanguine;
    public GameObject mist;
    public GameObject halls;
    public GameObject theater;

    public GameObject expandInterrupt;
    public InputField[] interruptInput;
    public Button expandBtn;
    public Button collapseBtn;

    public GameObject expandMega;
    public InputField[] megaInput;
    public Button expandMegaBtn;
    public Button collapseMegaBtn;
    
    public GameObject expandDos;
    public InputField dosNameInput1;
    public InputField dosValueInput1;
    public InputField dosNameInput2;
    public InputField dosValueInput2;
    public Button expandDosBtn;
    public Button collapseDosBtn;

    public GameObject expandSanguine;
    public Button expandSanguineBtn;
    public Button collapseSanguineBtn;

    public GameObject expandMist;
    public InputField[] mistInput;
    public Button expandMistBtn;
    public Button collapseMistBtn;
    public Toggle[] toggle;

    public GameObject expandHalls;
    public Button expandHallsBtn;
    public Button collapseHallsBtn;

    public GameObject expandTheater;
    public Button expandTheaterBtn;
    public Button collapseTheaterBtn;

    public InputField[] inputValues;

    public string pathBrowse;
    public string pathChoose;
    public List<string> profiles;
    public bool isExisted = false;
    public bool isLoading = false;

    void Start()
    {
        profiles = new List<string>();
        createInput.text = "profile";
        nickNameInput.characterLimit = 5;
        //PlayerPrefs.SetString("pathBrowse", "");
        pathBrowse = PlayerPrefs.GetString("pathBrowse");

        if (pathBrowse == "")
        {
            pathBrowse = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "\\Lord\\Bin\\Rotations";
            PlayerPrefs.SetString("pathBrowse", pathBrowse);
        }

        pathChoose = pathBrowse + "\\profile";
        browseInput.text = pathBrowse;
        chooseInput.text = pathChoose;

        createDropL.options.Clear();
        PathChoosing();
        OnClickAddBtn();

        //mainGUI.GetComponent<RectTransform>().localScale = new Vector3(1.0f /1366f * Screen.width, 1.0f / 768f * Screen.height, 1.0f);
    }

    private void Update()
    {        
        chooseInput.text = pathBrowse + "\\" + createDropL.options[createDropL.value].text;

        for (int i = 0; i < 4; i++)
        {
            if (toggle[i].isOn)
            {
                mistInput[i * 2].interactable = true;
                mistInput[i * 2 + 1].interactable = true;
            }
            else
            {
                mistInput[i * 2].interactable = false;
                mistInput[i * 2 + 1].interactable = false;
            }
        }

        if (isLoading)
        {
            if (Input.anyKeyDown && !Input.GetMouseButtonDown(0))
            {
                saveBtn.gameObject.SetActive(true);
            }
        }
    }

    //Load Menu
    public void OnClickLoadBtn()
    {
        loadMenu.SetActive(true);
        settingsMenu.SetActive(false);
        loadBtn.interactable = false;
        createDropL.interactable = true;
        isLoading = false;
        RefreshInput();
    }

    //Click Settings button
    public void OnClickSettingsBtn()
    {
        OnClickLoadBtnL();
    }

    //Click load button on the Load Menu
    public void OnClickLoadBtnL()
    {
        LoadSavedValue();
        loadMenu.SetActive(false);
        settingsMenu.SetActive(true);
        loadBtn.interactable = true;
        createDropL.interactable = false;
        isLoading = true;
        saveBtn.gameObject.SetActive(false);
    }

    //Add the profile to the list
    public void OnClickAddBtn()
    {
        isExisted = false;

        //Detect that this profile is existed or not               
        for (int i = 0; i < profiles.Count; i++)
        {
            if(profiles[i] == createInput.text)
            {
                isExisted = true;
                break;
            }
        }

        if (!isExisted && createInput.text != "")
        {
            pathChoose = pathBrowse + "\\" + createInput.text;
            Directory.CreateDirectory(pathChoose);

            if(profiles.Count > 0)
            {
                createDropL.options.Add(new Dropdown.OptionData() { text = createInput.text });
            }

            chooseInput.text = pathChoose;
            profiles.Add(createInput.text);

            FileStream oFileStream = new FileStream(pathChoose + "\\" + "Mega.txt", System.IO.FileMode.Create);
            oFileStream = new FileStream(pathChoose + "\\" + "Interrupt.txt", System.IO.FileMode.Create);
            oFileStream = new FileStream(pathChoose + "\\" + "Mist.txt", System.IO.FileMode.Create);
            oFileStream.Close();
        }

        for (int i = 0; i < createDropL.options.Count; i++)
        {
            if(createDropL.options[i].text == createInput.text)
            {
                createDropL.value = i;
                break;
            }
        }

        profiles = new List<string>();
        createDropL.options.Clear();
        PathChoosing();
    }

    //Remove the profile list
    public void OnClickRemoveBtn()
    {
        pathBrowse = PlayerPrefs.GetString("pathBrowse");
        string temp = pathBrowse + "\\" + createInput.text;

        //#if UNITY_EDITOR
        //    FileUtil.DeleteFileOrDirectory(temp); 
        //#endif

        if (Directory.Exists(temp))
        {
            Directory.Delete(temp, true);
        }

        profiles.Remove(createInput.text);
        createDropL.options.Clear();

        for (int i = 0; i < profiles.Count; i++)
        {
            createDropL.options.Add(new Dropdown.OptionData() { text = profiles[i] });
        }

        if(profiles.Count == 0)
        {
            createDropL.options.Add(new Dropdown.OptionData() { text = "profile" });
        }

        createDropL.value = 0;
    }

    //Directory : Browse external application
    public void OnClickBrowseBtn()
    {
        pathBrowse = PlayerPrefs.GetString("pathBrowse");
        profiles = new List<string>();

        if (!Directory.Exists(pathBrowse))
        {
            Directory.CreateDirectory(pathBrowse);
        }

//#if UNITY_EDITOR
//        //pathBrowse = EditorUtility.OpenFilePanel("Overwrite with exe", pathBrowse, "exe");
//        pathBrowse = EditorUtility.OpenFolderPanel("Open...", pathBrowse, "Folder");
//#else
//        //pathBrowse = YOUROWNCLASS.EditorUtility.OpenFolderPanel("Open...", pathBrowse, "Folder");
//#endif

        var paths = StandaloneFileBrowser.OpenFolderPanel("Select Folder", pathBrowse, true);
        browseInput.text = paths[0].ToString();
        pathBrowse = browseInput.text;
        PlayerPrefs.SetString("pathBrowse", pathBrowse);
        createDropL.options.Clear();
        PathChoosing();
        //OnClickAddBtn();

        //if (pathBrowse != "")
        //{
        //    browseInput.text = pathBrowse;
        //    System.Diagnostics.Process.Start(pathBrowse);
        //}
        //else
        //{
        //    pathBrowse = PlayerPrefs.GetString("pathBrowse");
        //}
    }

    //Click Save Button
    public void OnClickSaveBtnS()
    {
        if(nickNameInput.text != "")
        {
            WriteString();
        }
        else
        {
            alert.SetActive(true);
        }      
    }

    public void OnClickOkBtn()
    {
        alert.SetActive(false);
    }

    public void OnClickCloseBtn()
    {
        Application.Quit();
    }

    //Modify here
    //************************************************************************************
    public void OnClickExpandMegaBtn()
    {
        expandMega.SetActive(true);
        expandMegaBtn.gameObject.SetActive(false);
        collapseMegaBtn.gameObject.SetActive(true);
        interrupt.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickCollapseMegaBtn()
    {
        expandMega.SetActive(false);
        expandMegaBtn.gameObject.SetActive(true);
        collapseMegaBtn.gameObject.SetActive(false);
        interrupt.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickExpandBtn()
    {
        expandInterrupt.SetActive(true);
        expandBtn.gameObject.SetActive(false);
        collapseBtn.gameObject.SetActive(true);
    }

    public void OnClickCollapseBtn()
    {
        expandInterrupt.SetActive(false);
        expandBtn.gameObject.SetActive(true);
        collapseBtn.gameObject.SetActive(false);
    }

    public void OnClickExpandDosBtn()
    {
        expandDos.SetActive(true);
        expandDosBtn.gameObject.SetActive(false);
        collapseDosBtn.gameObject.SetActive(true);
        sanguine.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
        mist.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
        theater.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
        halls.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickCollapseDosBtn()
    {
        expandDos.SetActive(false);
        expandDosBtn.gameObject.SetActive(true);
        collapseDosBtn.gameObject.SetActive(false);
        sanguine.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
        mist.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
        theater.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
        halls.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickExpandSanguineBtn()
    {
        expandSanguine.SetActive(true);
        expandSanguineBtn.gameObject.SetActive(false);
        collapseSanguineBtn.gameObject.SetActive(true);
        mist.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
        theater.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
        halls.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickCollapseSanguineBtn()
    {
        expandSanguine.SetActive(false);
        expandSanguineBtn.gameObject.SetActive(true);
        collapseSanguineBtn.gameObject.SetActive(false);
        mist.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
        theater.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
        halls.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickExpandMistBtn()
    {
        expandMist.SetActive(true);
        expandMistBtn.gameObject.SetActive(false);
        collapseMistBtn.gameObject.SetActive(true);
        theater.transform.position -= new Vector3(0,182f / 768f * Screen.height, 0);
        halls.transform.position -= new Vector3(0, 182f / 768f * Screen.height, 0);
    }

    public void OnClickCollapseMistBtn()
    {
        expandMist.SetActive(false);
        expandMistBtn.gameObject.SetActive(true);
        collapseMistBtn.gameObject.SetActive(false);
        theater.transform.position += new Vector3(0,182f / 768f * Screen.height, 0);
        halls.transform.position += new Vector3(0, 182f / 768f * Screen.height, 0);
    }

    public void OnClickExpandHallsBtn()
    {
        expandHalls.SetActive(true);
        expandHallsBtn.gameObject.SetActive(false);
        collapseHallsBtn.gameObject.SetActive(true);
        theater.transform.position -= new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickCollapseHallsBtn()
    {
        expandHalls.SetActive(false);
        expandHallsBtn.gameObject.SetActive(true);
        collapseHallsBtn.gameObject.SetActive(false);
        theater.transform.position += new Vector3(0, 92f / 768f * Screen.height, 0);
    }

    public void OnClickExpandTheaterBtn()
    {
        expandTheater.SetActive(true);
        expandTheaterBtn.gameObject.SetActive(false);
        collapseTheaterBtn.gameObject.SetActive(true);
    }

    public void OnClickCollapseTheaterBtn()
    {
        expandTheater.SetActive(false);
        expandTheaterBtn.gameObject.SetActive(true);
        collapseTheaterBtn.gameObject.SetActive(false);
    }
    //*************************************************************************************


    //Text file output
    public void WriteString()
    {
        string path = browseInput.text + "\\" + "Macro.txt";
        string writeTemp = "";
        StreamWriter writer = new StreamWriter(path, true);
        writeTemp += "#showtooltip Mega" + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + megaInput[0].text + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + megaInput[2].text + "\n";

        writeTemp += "#showtooltip DoS" + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[0].text + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[1].text + "\n";

        writeTemp += "#showtooltip Sanguine" + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[2].text + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[3].text + "\n";

        writeTemp += "#showtooltip Mist" + "\n";

        for (int i = 0; i < 4; i++)
        {
            if (toggle[i].isOn)
            {
                writeTemp += "/ " + nickNameInput.text + " Do " + mistInput[i * 2].text + "\n";
            }
        }

        writeTemp += "#showtooltip Halls" + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[4].text + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[5].text + "\n";

        writeTemp += "#showtooltip Theater" + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[6].text + "\n";
        writeTemp += "/ " + nickNameInput.text + " Do " + interruptInput[7].text + "\n";        

        writer.WriteLine(writeTemp);
        writer.Close();

        //Modify here
        path = chooseInput.text + "\\" + "Mega.txt";
        FileStream oFileStream = new FileStream(path, System.IO.FileMode.Create);
        oFileStream.Close();
        writeTemp = "";
        writer = new StreamWriter(path, true);

        for(int i = 0; i < 4; i++)
        {
            writeTemp += megaInput[i].text + " ";
        }

        writeTemp += "\n";
        writer.WriteLine(writeTemp);
        writer.Close();

        path = chooseInput.text + "\\Interrupt.txt";
        oFileStream = new FileStream(path, System.IO.FileMode.Create);
        oFileStream.Close();
        writeTemp = "";
        writer = new StreamWriter(path, true);

        for (int i = 0; i < 16; i++)
        {
            writeTemp += interruptInput[i].text + " ";
        }

        writeTemp += "\n";
        writer.WriteLine(writeTemp);
        writer.Close();

        path = chooseInput.text + "\\Mist.txt";
        oFileStream = new FileStream(path, System.IO.FileMode.Create);
        oFileStream.Close();
        writeTemp = "";
        writer = new StreamWriter(path, true);

        for(int i = 0; i < 4; i++)
        {
            if (toggle[i].isOn)
            {
                writeTemp += "1 " + mistInput[i * 2].text + " " + mistInput[i * 2 + 1].text + " ";
            }
            else
            {
                writeTemp += "0 " + "NoSpell" + " " + "NoValue" + " ";
            }
        }

        writer.WriteLine(writeTemp);
        writer.Close();
    }

    public void PathChoosing()
    {
        if (Directory.Exists(pathBrowse))
        {
            string worldsFolder = pathBrowse;
            DirectoryInfo d = new DirectoryInfo(worldsFolder);
            string[] folders= System.IO.Directory.GetDirectories(pathBrowse, "*", System.IO.SearchOption.TopDirectoryOnly);

            for (int i = 0; i < folders.Length; i++)
            {
                string temp = "";

                for (int j = 0; j < folders[i].Length; j++)
                {
                    if(folders[i][j] == '\\')
                    {
                        temp = "";
                    }
                    else
                    {
                        temp += folders[i][j];
                    }
                }             

                profiles.Add(temp);
            }
        }

        for (int i = 0; i < profiles.Count; i++)
        {
            //if (profiles[i] != "profile")
            //{
            //    createDropL.options.Add(new Dropdown.OptionData() { text = profiles[i] });
            //}
            createDropL.options.Add(new Dropdown.OptionData() { text = profiles[i] });
        }
    }

    public void LoadSavedValue()
    {
        string path = chooseInput.text + "\\Mega.txt";
        StreamReader reader = new StreamReader(path);
        string readStr = reader.ReadToEnd();
        string temp = "";
        int num = 0;

        for(int i = 0; i < readStr.Length; i++)
        {
            if(readStr[i] == ' ')
            {
                megaInput[num].text = temp;
                num++;
                temp = "";
            }
            else
            {
                temp += readStr[i];
            }
        }
        
        reader.Close();

        path = chooseInput.text + "\\Interrupt.txt";
        reader = new StreamReader(path);
        readStr = reader.ReadToEnd();
        temp = "";
        num = 0;

        for (int i = 0; i < readStr.Length; i++)
        {
            if (readStr[i] == ' ')
            {
                interruptInput[num].text = temp;
                num++;
                temp = "";
            }
            else
            {
                temp += readStr[i];
            }
        }

        reader.Close();

        path = chooseInput.text + "\\Mist.txt";
        reader = new StreamReader(path);
        readStr = reader.ReadToEnd();
        List<string> saveTemp; 
        temp = "";

        saveTemp = new List<string>();

        for (int i = 0; i < readStr.Length; i++)
        {
            if (readStr[i] == ' ')
            {
                saveTemp.Add(temp);
                temp = "";
            }
            else
            {
                temp += readStr[i];
            }
        }

        reader.Close();

        if(saveTemp.Count != 0)
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    if (j == 0)
                    {
                        if (saveTemp[i * 3][0] == '1')
                        {
                            toggle[i].isOn = true;
                        }
                    }
                    else
                    {
                        mistInput[i * 2 + j - 1].text = saveTemp[i * 3 + j];
                    }
                }
            }
        }        
    }

    public void RefreshInput()
    {
        for(int i = 0; i < 28; i++)
        {
            inputValues[i].text = "";
        }
    }
}